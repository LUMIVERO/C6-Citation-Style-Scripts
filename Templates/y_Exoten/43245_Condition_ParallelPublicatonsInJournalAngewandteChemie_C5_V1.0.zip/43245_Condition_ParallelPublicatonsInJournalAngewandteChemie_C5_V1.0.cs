// #C5_43245
using System;

namespace SwissAcademic.Citavi.Citations
{
	public class CustomTemplateCondition
		:
		ITemplateConditionMacro
	{
		public bool IsTemplateForReference(ConditionalTemplate template, Citation citation)
		{
			//make sure, the important fields have data
			if (citation == null) return false;
			if (citation.Reference == null) return false;
			if (citation.Reference.Periodical == null) return false;


			//this should only work for linking a parallel publication in "Angew. Chem. Int. Ed." to the german original publication in "Angew. Chem."
			if (!citation.Reference.Periodical.StandardAbbreviation.Equals("Angew. Chem.", StringComparison.OrdinalIgnoreCase)) return false;

			//the sequence number of the parallel publication should be stored in CustomField1 of the original publication 
			int sequenceNumberParallelPublication;
			if (!int.TryParse(citation.Reference.CustomField1, out sequenceNumberParallelPublication)) return false;

			//get a reference to the parallel publication, if there is no publication with such sequence number in the project, return false
			Project project = ((SwissAcademic.Citavi.Reference)citation.Reference).Project;
			Reference parallelPublication = SwissAcademic.Citavi.ReferenceCollectionExtension.FindSequenceNumber(project.References, sequenceNumberParallelPublication);
			if (parallelPublication == null) return false;
			if (parallelPublication.Periodical == null) return false;

			//get a reference to the original publication, the one behind the current citation
			Reference originalPublication = (Reference)citation.Reference;

			//gather output info of parralel publication ...
			string titleSupplementTagged = string.Empty;

			//... periodical name ...
			string periodicalName = string.Empty;
			if ((parallelPublication.Periodical != null) && !string.IsNullOrEmpty(parallelPublication.Periodical.StandardAbbreviation))
			{
				periodicalName = "<i>" + parallelPublication.Periodical.StandardAbbreviation + "</i>";
			}
			titleSupplementTagged = titleSupplementTagged + (string.IsNullOrEmpty(titleSupplementTagged) ? periodicalName : ", " + periodicalName);


			//... year ...
			string yearOfPublication = string.Empty;
			if (!string.IsNullOrEmpty(parallelPublication.YearResolved))
			{
				yearOfPublication = "<b>" + parallelPublication.YearResolved + "</b>";
			}
			titleSupplementTagged = titleSupplementTagged + (string.IsNullOrEmpty(titleSupplementTagged) ? yearOfPublication : ", " + yearOfPublication);


			//... volumne number ...
			string volumeNumber = string.Empty;
			if (!string.IsNullOrEmpty(parallelPublication.Volume))
			{
				volumeNumber = "<i>" + parallelPublication.Volume + "</i>";
			}
			titleSupplementTagged = titleSupplementTagged + (string.IsNullOrEmpty(titleSupplementTagged) ? volumeNumber : ", " + volumeNumber);


			//... page range.
			string pageRange = string.Empty;
			if (!string.IsNullOrEmpty(parallelPublication.PageRange))
			{
				pageRange = parallelPublication.PageRange;
			}
			titleSupplementTagged = titleSupplementTagged + (string.IsNullOrEmpty(titleSupplementTagged) ? pageRange : ", " + pageRange);


			//exit if nothing to output
			if (string.IsNullOrEmpty(titleSupplementTagged)) return false;


			//place data into field
			originalPublication.TitleSupplementTagged = titleSupplementTagged;

			return true;
		}
	}
}