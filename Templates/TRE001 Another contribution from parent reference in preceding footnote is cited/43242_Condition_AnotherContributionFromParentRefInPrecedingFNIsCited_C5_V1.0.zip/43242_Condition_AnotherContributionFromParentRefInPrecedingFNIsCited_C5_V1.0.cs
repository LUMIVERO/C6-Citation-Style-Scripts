// #C5_43242
//Version 1.0

using System.Linq;
using System.Collections.Generic;
using SwissAcademic.Citavi;
using SwissAcademic.Citavi.Metadata;
using SwissAcademic.Collections;

namespace SwissAcademic.Citavi.Citations
{
	public class CustomTemplateCondition
		:
		ITemplateConditionMacro
	{
		public bool IsTemplateForReference(ConditionalTemplate template, Citation citation)
		{
			//Ein anderer Beitrag desselben übergeordneten Titels wurde unmittelbar zuvor in derselben Fußnote bereits zitiert
			
			if (citation == null) return false;
			if (citation.Reference == null) return false;
			if (citation.Reference.ParentReference == null) return false;
			
			var thisFootnoteCitation = citation as FootnoteCitation;
			if (thisFootnoteCitation == null) return false;
			
			var previousFootnoteCitation = thisFootnoteCitation.PreviousFootnoteCitation;
			if (previousFootnoteCitation == null) return false;
			
			if (previousFootnoteCitation.FootnoteIndex != thisFootnoteCitation.FootnoteIndex) return false;
			if (previousFootnoteCitation.Reference == null) return false;
			if (previousFootnoteCitation.Reference == thisFootnoteCitation.Reference) return false;
			if (previousFootnoteCitation.Reference.ParentReference == null) return false;
			if (previousFootnoteCitation.Reference.ParentReference != thisFootnoteCitation.Reference.ParentReference) return false;

			
			//alle Bedingungen erfüllt
			return true;
		}
	}
}