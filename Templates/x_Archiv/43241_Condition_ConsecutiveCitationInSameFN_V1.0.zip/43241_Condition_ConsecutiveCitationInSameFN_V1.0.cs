//#43241
//Version 1.0

using System.Linq;
using System.Collections.Generic;
using SwissAcademic.Citavi;
using SwissAcademic.Citavi.Metadata;
using SwissAcademic.Collections;

namespace SwissAcademic.Citavi.Citations
{
	public class CustomTemplateCondition
		:
		ITemplateConditionMacro
	{
		public bool IsTemplateForReference(ConditionalTemplate template, Citation citation)
		{
			//Name der Bedingung: Titel wird zum wiederholten mal unmittelbar hintereinander in derselben Word-Fussnote zitiert
			
			if (citation == null) return false;
			if (citation.Reference == null) return false;
			
 			// aktuelle Zitation ist in einer Fussnote und sie ist eine wiederholte Zitation
            FootnoteCitation footnoteCitation = citation as FootnoteCitation;
            if (footnoteCitation == null || !footnoteCitation.IsRepeatingFootnote) return false;
		
			// aktuelle Zitation hat einen unmittelbaren Vorgänger
			FootnoteCitation previousFootnoteCitation = footnoteCitation.PreviousFootnoteCitation;
            if (previousFootnoteCitation == null) return false;
			
			// aktuell zitierter Titel muss gleich dem unmittelbar zuvor zitierten Titel sein
            if (footnoteCitation.Reference != previousFootnoteCitation.Reference) return false;

			// aktuelle Zitation ist in derselben Word-Fussnote wie der unmittelbare Vorgänger
            if (footnoteCitation.FootnoteIndex > previousFootnoteCitation.FootnoteIndex) return false;
         
          	// Vorgänger muss alleine sein in seiner Fussnote
          	//FootnoteCitation previousPreviousFootnoteCitation = previousFootnoteCitation.PreviousFootnoteCitation;
          	//if (previousPreviousFootnoteCitation != null && previousPreviousFootnoteCitation.FootnoteIndex == previousFootnoteCitation.FootnoteIndex) return false;
          
            // zur Überprüfung der Zitatseiten müssen wir den PlaceholderEntry bemühen:
            //if (footnoteCitation.Entry == null || previousFootnoteCitation.Entry == null) return false;
             
            // dies vergleicht die exakten Angaben am Platzhalter im Word Dokument in bezug auf Seitenbereich
            //if (footnoteCitation.Entry.PageRange != previousFootnoteCitation.Entry.PageRange) return false;
                     
            return true;
		}
	}
}