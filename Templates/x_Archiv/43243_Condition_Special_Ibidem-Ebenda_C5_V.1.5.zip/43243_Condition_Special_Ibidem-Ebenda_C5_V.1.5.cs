//Template Condition ibid./ebd. customizable 
//#C5_43243
//Version 1.5

using System.Linq;
using System.Collections.Generic;
using SwissAcademic.Citavi;
using SwissAcademic.Citavi.Metadata;
using SwissAcademic.Collections;


namespace SwissAcademic.Citavi.Citations
{
	public class CustomTemplateCondition
	   :
	   ITemplateConditionMacro
	{
		public bool IsTemplateForReference(ConditionalTemplate template, Citation citation)
		{
			//ibid./ebd. condition (customizable)
			bool crossFootnote = true;							//if true, the condition will search across footnotes
			int maxFootnoteDistance = 1;						//only will be applied if crossFootnote = true: if 1 "ibid./ebd." will not be applied if a citation-free footnote 	appears between two citation-containing footnotes
			bool immediatePredecessorOnly = true;				//should always be set to true for "ibid./ebd."
			bool ensurePredecessorIsInFootnoteOfItsOwn = true;	//only will be applied if crossFootnote = true
			bool ignoreQuotationPageRange = true;
			


			if (citation == null) return false;
			if (citation.Reference == null) return false;
			
			CitationManager citationManager = citation.CitationManager;
			if (citationManager == null) return false;

			// current citation is in a footnote and is a repeated citation
			FootnoteCitation currentFootnoteCitation = citation as FootnoteCitation;
			if (currentFootnoteCitation == null) return false;

			PlaceholderEntry currentFootnoteCitationEntry = currentFootnoteCitation.Entry;
			if (currentFootnoteCitationEntry == null) return false;			
			

			int currentCitationIndex = currentFootnoteCitation.Index;
			if (currentCitationIndex == 0) return false;
			
			int currentFootnoteIndex = currentFootnoteCitation.FootnoteIndex;

			
			for (int i = currentCitationIndex - 1; i >= 0; i--)
			{
				FootnoteCitation previousFootnoteCitation = citationManager.FootnoteCitations[i];
				if (previousFootnoteCitation == null) break;

				if (previousFootnoteCitation.Reference == null) break;

				PlaceholderEntry previousFootnoteCitationEntry = previousFootnoteCitation.Entry;
				if (previousFootnoteCitationEntry == null) break;
				
				int previousCitationIndex = (int)previousFootnoteCitation.Index;
				int previousFootnoteIndex = (int)previousFootnoteCitation.FootnoteIndex;
				
				if (immediatePredecessorOnly && currentCitationIndex - previousCitationIndex != 1) break;
				if (!crossFootnote && !previousFootnoteIndex.Equals(currentFootnoteIndex)) break;			//do NOT use == or != here					
				if (crossFootnote && currentFootnoteIndex - previousFootnoteIndex > maxFootnoteDistance) break;

				if (ensurePredecessorIsInFootnoteOfItsOwn)
				{
					FootnoteCitation secondPreviousFootnoteCitation = previousFootnoteCitation.PreviousFootnoteCitation;
					if (secondPreviousFootnoteCitation != null)
					{
						int secondPreviousFootnoteIndex = (int)secondPreviousFootnoteCitation.FootnoteIndex;
						if (secondPreviousFootnoteIndex.Equals(previousFootnoteIndex)) break;
					}
				}

				//ibid./ebd. (same reference, same page numbers)
				if 
				(
					currentFootnoteCitation.Reference == previousFootnoteCitation.Reference &&
					(
						ignoreQuotationPageRange ||
						IsPageRangeIdentical(currentFootnoteCitationEntry.PageRange, previousFootnoteCitationEntry.PageRange)
					)
				)
				return true;
			}

			//still here?
			return false;
		}

		private bool IsPageRangeIdentical(PageRange pageRangeX, PageRange pageRangeY)
		{
			if (pageRangeX == null)
			{
				if (pageRangeY == null)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			else
			{
				if (pageRangeY == null)
				{
					return false;
				}
				else
				{
					return pageRangeX == pageRangeY;
				}
			}
		}

	}
}